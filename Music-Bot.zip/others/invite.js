const Discord = require('discord.js')
const { MessageButton } = require('discord-buttons');

module.exports = {
  name: "invite",
  aliases: ["inv"],
  description: "Invite the bot to your server.",
   async execute(message, args, client) {

      return message.channel.send(embed);

    let embed = new Discord.MessageEmbed()
      .setTitle("Invite me to your server!")
      .setDescription("Love using Tune? Add it to your server now!")
      .setColor("#1297f8")
      .setFooter(client.user.username, client.user.displayAvatarURL({ size: 4096, dynamic: true}))
      .setThumbnail(message.guild.iconURL())
      .addField("Add Tune to your server!", "[Click here to invite me](https://discord.com/oauth2/authorize?client_id=885774822414643200&scope=bot&permissions=6777466704)")
      .addField("Join Suport server!", "[Click here](https://discord.gg/R3mZa3K6Qu)")

    
  }
    
  };        
            