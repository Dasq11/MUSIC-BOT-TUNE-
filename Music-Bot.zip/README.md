# Tune
Tune is a powerful music bot which allows you to easily search music on youtube and listen to them in discord voice channel.

## Developers
Tune is a discord music bot made by 𝖕𝖍𝖊𝖓𝖔𝖎𝖝々#8396, 8N Films#0492 and Fᴜʀʏ々Gʜᴏsᴛ࿐👑#8577