const { Client, Collection, MessageEmbed } = require(`discord.js`);
const db = require('quick.db');

module.exports = {
  name: `premium`,
  execute(message,args,client) {
let premium = db.fetch(`premium_${message.guild.id}`)

  if (premium == false) {
  return message.channel.send('This server do not have Tune premium!')
  } else if (premium == true) {
    let embed = new MessageEmbed()
    .setTitle('Tune premium')
    .setDescription('This server has Tune premium. These are the premium commands.')
    .setColor("#1297f8")
     message.channel.send(embed)
    }

  }
};