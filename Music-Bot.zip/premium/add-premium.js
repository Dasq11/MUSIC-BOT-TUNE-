const { Client, Collection, MessageEmbed } = require(`discord.js`);
const db = require('quick.db');

module.exports = {
  name: `add-premium`,                    //dont edit
  execute(message,args,client) {
    let botDev = '885774822414643200'
    if (!message.author.id === botDev ) {
      return message.reply('Only bot owner can use this command.')
    } else
    db.set(`premium_${message.guild.id}`, true);
    let embed = new MessageEmbed()
    .setDescription('**\<a:loading:887352558564290561> This server can now use Tune\'s premium commands.**')
    .setColor("#1297f8")
     message.channel.send(embed)

    }
}